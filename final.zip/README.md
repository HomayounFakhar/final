Web store web store
React JS & Firebase


Sample of WebStore
Include Routing , Global Variable , UseState and ... 
Design by "ant.design"


How to install ant.design
https://ant.design/docs/react/use-with-create-react-app


Live static on
Sarafan.Today

npm install react-axios
npm install axios
npm install react
npm install firestore-export-import

Optional
npm install prop-types


Developer :
Homayoun Fakhar

2021 April